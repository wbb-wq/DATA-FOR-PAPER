import csv

import xlsxwriter
import openpyxl
from gurobipy import*
import matplotlib.pyplot as plt
import math

#该函数用于生成不同常低温产品比例的数据，导出txt格式

#最初常低温产品比例
ratio=[664,1391]

#1、读取原始数据
class Par:
  def __init__(self):
      self.N = []  ## 所有点集合
      self.P = []  ## Set of Different Product
      self.K = []  ## Set of Vehicles
      self.T = []  ## set of time period
      self.Q = {}  ## Fleet Size
      self.co = {}  ## Co-ordinates of DEPOT and RATM
      self.cij = {}  ## Travelling Distance
      self.Iti_1 = {}  ## initial inventory level
      self.Produ = {}  ## production of product{p,t}
      self.h = {}  ## Holding Cost  {i,p}
      self.D = {}  ## Demand of products {I,P,T}
      self.P1 = []                     ## Set of 常温 Product
      self.P2 = []                     ## Set of 低温 Product
      self.U = {}                     ## {(第i个网点，第j类产品)：库存上限}
      self.U1 = {}                     ## {第i个网点：常温库存上限}
      self.U2 = {}                    ## {第i个网点：低温库存上限}
      self.f = {}                      ##{p,1/-1},产品常温、低温属性
      self.e = {}                      ##{k,1/-1}车辆常温、低温属性
      self.vk = {}                     ##{k,value}第k辆车均公里成本
      self.s = {}                      ##{k,value}车辆速度
      self.g = {}                      ##{k,value}车辆可用时间
      self.w = 30                      ## 在每个点的服务时间


def calculate_dist(x1, x2):#计算两个点之间的距离 (x,y)
    eudistance = int( ( (x1[0]-x2[0])**2+(x1[1]- x2[1])**2 )**0.5 + 0.5 )
    return eudistance

def MMIRPdata(path,name):
    data = Par()
    original_text = open(path+name, 'r')
    text_lines = original_text.readlines()
    # read the info
    for i in range(len(text_lines)):
        line_text = text_lines[i].strip('\n').split()
        if i == 0:
            data.N = [i for i in range(1,int(line_text[0])+1)]
            data.P = [i for i in range(1,int(line_text[1])+1)]
            data.K = [i for i in range(1,int(line_text[2])+1)]
            data.T = [i for i in range(1,int(line_text[3])+1)]
        elif i == 1:
            data.co[i] = (int(line_text[0]),int(line_text[1]))
        elif i == 2:
            for j in data.P:
                data.Iti_1[1,j] = int(line_text.pop(0))
            for j in data.P:
                for t in data.T:
                    data.Produ[j,t] = int(line_text.pop(0))
            for j in data.P:
                data.h[1,j] = float(line_text.pop(0))
        elif i <= len(text_lines) - 2:
            line_text.pop(0)
            data.co[i-1] = (int(line_text.pop(0)),int(line_text.pop(0)))
            for j in data.P:
                data.Iti_1[i-1,j] = int(line_text.pop(0))
            for j in data.P:
                for t in data.T:
                    data.D[i-1,j,t] = int(line_text.pop(0))
            for j in [1, 2]:
                data.U[i-1, j] = int(line_text.pop(0))
            data.U[i - 1, 3] = int(800)
            for j in data.P:
                data.h[i - 1, j] = float(line_text.pop(0))
        else:
            for p in data.P:
                data.f[p] = int(line_text.pop(0))
            for k in data.K:
                data.e[k] = int(line_text.pop(0))
                data.vk[k] = float(line_text.pop(0))
                data.s[k] = int(line_text.pop(0))
                data.g[k] = int(line_text.pop(0))
                data.Q[k] = int(line_text.pop(0))
            data.w = int(line_text.pop(0))
    # 距离
    for i in data.N:
        for j in data.N:
            data.cij[i, j] = int(calculate_dist(data.co[i], data.co[j]))
    # 产品集合
    for p in data.P:
        if data.f[p] == 1:
            data.P1.append(p)
        else:
            data.P2.append(p)

    for i in data.N[1:]:
        temp=0
        for p in data.P1:
            temp +=data.U[i,p]
        data.U1[i]=temp
        temp1 = 0
        for p in data.P2:
            temp1 += data.U[i, p]
            data.U2[i] = temp1
    return data


file_name = '需求比例原始.txt'
# name = '10-1-1-3-1'
input_path = 'C:/Users/DELL/Desktop/机械式和蓄冷式/案例数据/'
# path = 'C:/Users/乖乖/Nutstore/1/4_PHD论文/1_大论文/2.小论文的资料/第四章/MMIRP/Benchmark/data/'
data = MMIRPdata(input_path, file_name)

#2、根据比例调整各网点的需求量
#计算每个网点每个周期的需求总量
total_demand_P1=sum(data.D.get((i,p,t),0) for i in data.N[1:] for p in data.P1 for t in data.T)
total_demand_P2=sum(data.D.get((i,p,t),0) for i in data.N[1:] for p in data.P2 for t in data.T)
#按照给定比例拆分，假设两类低温产品的需求量一致
a = 1
b = 9
ratio=[a,b]
#计算常低温产品的需求量
modify_total_demand_P1 = a/(a+b)*(total_demand_P1+total_demand_P2)
modify_total_demand_P2 = b/(a+b)*(total_demand_P1+total_demand_P2)

#重置低温产品的需求
for i in data.N[1:]:
    for p in data.P2:
        for t in data.T:
            data.D[i,p,t]=modify_total_demand_P2/(data.N[-1]+1)/data.T[-1]/2  #两类低温产品，平均分配低温需求量


for i in data.N[1:]:
    for p in data.P1:
        for t in data.T:
            data.D[i,p,t]=modify_total_demand_P1/(data.N[-1]+1)/data.T[-1]

#3、导出新生成的数据txt格式
with open('需求比例5.txt','w') as file:
    N=5
    P=3
    k=6
    T=3
    file.write(f'{N} {P} {k} {T} {986}\n')  # 第一行

    i=1
    value=data.co[i]
    file.write(f'{value[0]} {value[1]}\n')#第二行

    i=1
    for p in data.P:
        value1=data.Iti_1[i,p]
        file.write(f'{value1} ')

    for p in data.P:
        for t in data. T:
            value2 = data.Produ[p,t]
            file.write(f'{value2} ')

    for p in data.P:
        value3 = data.h[i,p]
        file.write(f'{value3} ')#第三行
    file.write(f' \n')


    i=2
    value5=data.N[i-1]
    file.write(f'{value5} ')

    value=data.co[i]
    file.write(f'{value[0]} {value[1]} ')

    for p in data.P:
        value1=data.Iti_1[i,p]
        file.write(f'{value1} ')

    for p in data.P:
        for t in data.T:
            value4=data.D[i,p,t]
            float_value4 = value4
            int_value4 = math.ceil(float_value4)
            file.write(f'{int_value4} ')

    for p in data.P:
        value6=data.U[i,p]
        file.write(f'{value6} ')


    for p in data.P:
        value3 = data.h[i,p]
        file.write(f'{value3} ')#第四行
    file.write(f' \n')

    i=3
    value5=data.N[i-1]
    file.write(f'{value5} ')

    value=data.co[i]
    file.write(f'{value[0]} {value[1]} ')

    for p in data.P:
        value1=data.Iti_1[i,p]
        file.write(f'{value1} ')


    for p in data.P:
        for t in data.T:
            value4=data.D[i,p,t]
            float_value4 = value4
            int_value4 = math.ceil(float_value4)
            file.write(f'{int_value4} ')

    for p in data.P:
        value6=data.U[i,p]
        file.write(f'{value6} ')

    for p in data.P:
        value3 = data.h[i,p]
        file.write(f'{value3} ')#第五行
    file.write(f' \n')

    i=4
    value5=data.N[i-1]
    file.write(f'{value5} ')

    value=data.co[i]
    file.write(f'{value[0]} {value[1]} ')

    for p in data.P:
        value1=data.Iti_1[i,p]
        file.write(f'{value1} ')


    for p in data.P:
        for t in data.T:
            value4=data.D[i,p,t]
            float_value4 = value4
            int_value4 = math.ceil(float_value4)
            file.write(f'{int_value4} ')

    for p in data.P:
        value6=data.U[i,p]
        file.write(f'{value6} ')

    for p in data.P:
        value3 = data.h[i,p]
        file.write(f'{value3} ')#第六行
    file.write(f' \n')

    i=5
    value5=data.N[i-1]
    file.write(f'{value5} ')

    value=data.co[i]
    file.write(f'{value[0]} {value[1]} ')

    for p in data.P:
        value1=data.Iti_1[i,p]
        file.write(f'{value1} ')


    for p in data.P:
        for t in data.T:
            value4=data.D[i,p,t]
            float_value4 = value4
            int_value4 = math.ceil(float_value4)
            file.write(f'{int_value4} ')

    for p in data.P:
        value6=data.U[i,p]
        file.write(f'{value6} ')

    for p in data.P:
        value3 = data.h[i,p]
        file.write(f'{value3} ')#第七行
    file.write(f' \n')

    for p in data.P:
        value6=data.f[p]
        file.write(f'{value6} ')
    for k in data.K:
       value7 = data.e[k]
       file.write(f'{value7} ')

       value8 = data.vk[k]
       file.write(f'{value8} ')

       value9=data.s[k]
       file.write(f'{value9} ')

       value10 = data.g[k]
       file.write(f'{value10} ')

       value11=data.Q[k]
       file.write(f'{value11} ')

    value12=data.w
    file.write(f'{value12} \n')#第八行
print('已经导入新数据到  需求比例5.txt')
