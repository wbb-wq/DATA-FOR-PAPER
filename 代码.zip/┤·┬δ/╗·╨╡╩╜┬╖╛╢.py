import xlsxwriter
import openpyxl
from gurobipy import*
import matplotlib.pyplot as plt
import pandas as pd
from openpyxl import Workbook
import os


class Par:
  def __init__(self):
      self.N = []  ## 所有点集合
      self.P = []  ## Set of Different Product
      self.K = []  ## Set of Vehicles
      self.T = []  ## set of time period
      self.Q = {}  ## Fleet Size
      self.co = {}  ## Co-ordinates of DEPOT and RATM
      self.cij = {}  ## Travelling Distance
      self.Iti_1 = {}  ## initial inventory level
      self.Produ = {}  ## production of product{p,t}
      self.h = {}  ## Holding Cost  {i,p}
      self.D = {}  ## Demand of products {I,P,T)
      self.P1 = []                     ## Set of 常温 Product
      self.P2 = []                     ## Set of 低温 Product
      self.U = {}                     ## {(第i个网点，第j类产品)：库存上限}
      self.U1 = {}                     ## {第i个网点：常温库存上限}
      self.U2 = {}                    ## {第i个网点：低温库存上限}
      self.f = {}                      ##{p,1/-1},产品常温、低温属性
      self.e = {}                      ##{k,1/-1}车辆常温、低温属性
      self.vk = {}                     ##{k,value}第k辆车均公里成本
      self.s = {}                      ##{k,value}车辆速度
      self.g = {}                      ##{k,value}车辆可用时间
      self.w = 30                      ## 在每个点的服务时间


def calculate_dist(x1, x2):#计算两个点之间的距离 (x,y)
    eudistance = int( ( (x1[0]-x2[0])**2+(x1[1]- x2[1])**2 )**0.5 + 0.5 )
    return eudistance

def chang_ijkt_rout(xijkt):
    kt = {}
    temp = []
    tour = {}
    for key in xijkt.keys():  # Extract arc data from ijkt
        if xijkt[key].x > 0.01:  # Changed from >0 to >0.5 for binary variables
            kt.setdefault((key[2], key[3]), []).append((key[0], key[1]))  # (k,t): [(i,j)]

    for (k, t), arcs in kt.items():
        # Create a graph of the route
        graph = {}
        for i, j in arcs:
            graph.setdefault(i, []).append(j)
            graph.setdefault(j, []).append(i)

        # Start from depot (node 1)
        if 1 not in graph:
            continue  # Skip if depot not in route

        path = []
        stack = [1]
        visited = set()

        while stack:
            node = stack.pop()
            if node not in visited:
                visited.add(node)
                path.append(node)
                # Add neighbors in reverse order for proper sequencing
                for neighbor in reversed(graph.get(node, [])):
                    if neighbor not in visited:
                        stack.append(neighbor)

        # Ensure the path returns to depot if it's a cycle
        if len(path) > 1 and path[-1] != 1:
            # Find the connection back to depot
            last_node = path[-1]
            if 1 in graph.get(last_node, []):
                path.append(1)

        tour[(k, t)] = path

    return tour

def PlotTour(tours, data, Tcolor):  # partial_solution不包含起始点
    # tours = [[1,2,3,5],[1,6,2,4],[]  ]
    "1.创建一张空白的图"
    plt.figure()
    "2.审查可行解中的每一条路径"
    for i in range(len(tours)):
        x, y = [], []
        "4.审查路径中的每一个点"
        for j in tours[i]:
            x.append(data.co[j][0])
            y.append(data.co[j][1])
            # plt.annotate(j, xy=(Data.cor_X[j], Data.cor_Y[j]), size=10)

        txt = [i for i in tours[i]]
        for i in range(len(x)):  # 在图中增加标签数据
            plt.annotate(txt[i], (x[i], y[i]))
        "6.标注客户点的坐标"
        plt.scatter(x, y, color=Tcolor)
        "7.标注起点坐标"
        plt.scatter(data.co[1][0], data.co[1][1], color='red', marker='D')
        "8.绘制该条路径线路"
        plt.plot(x, y)
    "9.填写坐标轴标签"
    plt.xlabel('Latitude')
    plt.ylabel('Longitude')
    "10.展示该图"
    plt.show()



def jixieshidata(path,name):
    data = Par()
    original_text = open(path+name, 'r')
    text_lines = original_text.readlines()
    # read the info
    for i in range(len(text_lines)):
        line_text = text_lines[i].strip('\n').split()
        if i == 0:
            data.N = [i for i in range(1,int(line_text[0])+1)]
            data.P = [i for i in range(1,int(line_text[1])+1)]
            data.K = [i for i in range(1,int(line_text[2])+1)]
            data.T = [i for i in range(1,int(line_text[3])+1)]
        elif i == 1:
            data.co[i] = (int(line_text[0]),int(line_text[1]))
        elif i == 2:
            for j in data.P:
                data.Iti_1[1,j] = int(line_text.pop(0))
            for j in data.P:
                for t in data.T:
                    data.Produ[j,t] = int(line_text.pop(0))
            for j in data.P:
                data.h[1,j] = float(line_text.pop(0))
        elif i <= len(text_lines) - 2:
            line_text.pop(0)
            data.co[i-1] = (int(line_text.pop(0)),int(line_text.pop(0)))
            for j in data.P:
                data.Iti_1[i-1,j] = int(line_text.pop(0))
            for j in data.P:
                for t in data.T:
                    data.D[i-1,j,t] = int(line_text.pop(0))
            for j in [1, 2]:
                data.U[i-1, j] = int(line_text.pop(0))
            data.U[i-1, 3] = int(800)
            for j in data.P:
                data.h[i - 1, j] = float(line_text.pop(0))
        else:
            for p in data.P:
                data.f[p] = int(line_text.pop(0))
            for k in data.K:
                data.e[k] = int(line_text.pop(0))
                data.vk[k] = float(line_text.pop(0))
                data.s[k] = int(line_text.pop(0))
                data.g[k] = int(line_text.pop(0))
                data.Q[k] = int(line_text.pop(0))
            data.w = int(line_text.pop(0))
    # 距离
    for i in data.N:
        for j in data.N:
            data.cij[i, j] = int(calculate_dist(data.co[i], data.co[j]))/10
    # 产品集合
    for p in data.P:
        if data.f[p] == 1:
            data.P1.append(p)
        else:
            data.P2.append(p)

    for i in data.N[1:]:
        temp=0
        for p in data.P1:
            temp +=data.U[i,p]
        data.U1[i]=temp
        temp1 = 0
        for p in data.P2:
            temp1 += data.U[i, p]
            data.U2[i] = temp1
    return data


file_name =  '测试数据11.txt'
input_path = 'C:/Users/鲸鱼/Desktop/机械式和蓄冷式/机械式和蓄冷式/案例数据/'
output_path = 'C:/Users/鲸鱼/Desktop/机械式和蓄冷式/机械式和蓄冷式/Results/'  # 结果文件保存路径
# 确保输出路径存在
if not os.path.exists(output_path):
    os.makedirs(output_path)

hold_chang_ratio = [1,2,3]
trans_chang_ratio = [0.1,0.3,-0.1,-0.2,-0.3]
trans_chang_ratio = [0]
lc=80 #制冷成本
Qc=120 #冷藏车厢的容量
Qb=100 #常温车厢的容量
ak=[0,400,420,440,400,420,440]#单位容量的低温产品的租车成本为0.7
for ratio in trans_chang_ratio:
    excel_name = "Result_MMMIRP_" + 'hold_' + str(ratio) + ".xlsx"
    workbook = xlsxwriter.Workbook(excel_name)
    worksheet = workbook.add_worksheet('1')
    worksheet = workbook.add_worksheet('2')
    worksheet = workbook.add_worksheet('3')
    workbook.close()

data = jixieshidata(input_path, file_name)
for key in data.vk:
    data.vk[key] = data.vk[key] + data.vk[key] * ratio

##################     MODEL   ##################
N_Dash = data.N[1:]
m = Model("Basic model Of duowengongpei")
m.modelSense = GRB.MINIMIZE

print('Run Model')
##################   VARIABLES   ##################
xijkt = m.addVars(data.N, data.N, data.K, data.T, vtype=GRB.BINARY, name='X_ijkt')  ## Route variable Binary
Iitp = m.addVars(data.N, data.T, data.P, vtype=GRB.INTEGER, name='I_itp')  ## Inventory level of each node at the end of period
qiktp = m.addVars(data.N, data.K, data.T, data.P, vtype=GRB.INTEGER, name='q_iktp')  ## amount of quantity delivered or pickup in period t by vehicle k
yikt = m.addVars(data.N, data.K, data.T, vtype=GRB.BINARY, name='Y_ikt')  ## Integer variable visiting Variable to node
Uikt = m.addVars(data.N,data.K,data.T,  vtype=GRB.INTEGER,name='U_ikt' )    ## Subtour elimination variable
mk=m.addVars(data.K,vtype=GRB.BINARY,name='M_k' )  ##是否使用第k台车辆
skc=m.addVars(data.K,vtype=GRB.INTEGER,name='S_k')##使用常温车厢的数量
skb = m.addVars(data.K, vtype=GRB.INTEGER, name='S_k1')  ##使用冷藏车厢的数量
yk=m.addVars(data.K,vtype=GRB.BINARY,name='Y_k')
#############   OBJECTIVE FUNCTION   #############
m.setObjective(
    sum(data.h[i,p] * data.Iti_1[i,p] for i in data.N for p in data.P)+
    sum(data.h[i,p] * Iitp[i,t, p] for i in data.N for t in data.T for p in data.P) +
    sum(data.vk[k] *data.cij[i,j] * xijkt[ i,j,k,t] for i in data.N for j in data.N for k in data.K for t in data.T)+
    sum(lc * skc[k] for k in data.K)+sum(lc  * skb[k] for k in data.K)+sum(ak[k] * mk[k] for k in data.K))

################## CONSTRAINTS ##################
                         ##库存类约束
###Constraint （1）（2） : 常低温产品的库存要大于0小于上限
for i in N_Dash:
    for t in data.T:
        exp = LinExpr()
        for p in data.P1:
            exp.add(Iitp[i,t, p], 1)
        m.addConstr(exp <= data.U1[i])

        exp1 = LinExpr()
        for p in data.P2:
            exp1.add(Iitp[i,t, p], 1)
        m.addConstr(exp1 <= data.U2[i])

###Constraint （4）:   非枢纽站库存转换的计算等式
for i in N_Dash:
    for t in data.T:
        for p in data.P:
            if t == 1:#计算的是各周期末，末端网点的库存量
                m.addConstr(Iitp[i,t, p] == data.Iti_1[i, p] + sum(qiktp[i,k,t,p] for k in data.K) - data.D[i,p,t] )
            else:
                m.addConstr(Iitp[i,t, p] == Iitp[i,t-1, p] + sum( qiktp[i,k,t,p] for k in data.K ) - data.D[i,p,t] )
###Constraint （5）:   仓储中心库存的计算等式
for t in data.T:
    for p in data.P:
        if t == 1:#计算的是各周期末，配送中心的库存量
            m.addConstr(Iitp[1,t, p] == data.Iti_1[1, p] + data.Produ[p,t] - sum(qiktp[i,k,t,p] for k in data.K for i in N_Dash))
        else:
            m.addConstr(Iitp[1,t, p] == Iitp[1,t-1, p] + data.Produ[p,t] - sum(qiktp[i,k,t,p] for k in data.K for i in N_Dash) )
###Constraint （6）: 库存要大于等于0
for i in data.N:
    for p in data.P:
        for t in data.T:
            m.addConstr(Iitp[i,t, p] >= 0)
####Constraint （7）:产品品类与运输品类相同
#for t in data.T:
#   for k in data.K:
#      m.addConstr(sum(qiktp[i,k,t,p] for i in N_Dash for p in data.P) == sum([qiktp[i,k,t,p] * data.f[p] * data.e[k] for i in N_Dash for p in data.P]))

                    ##策略类约束
###Constraint （8）:车载容量约束
for k in data.K:
    for t in data.T:
        m.addConstr(sum(qiktp[i,k,t,p] for i in N_Dash for p in data.P) <= data.Q[k]*yikt[1,k,t])

for k in data.K:
    for t in data.T:
             m.addConstr((sum(qiktp[i, k, t, p] for i in N_Dash for p in data.P1)/Qc)<=skc[k])
for k in data.K:
    for t in data.T:
        m.addConstr((sum(qiktp[i, k, t, p] for i in N_Dash for p in data.P1) / Qb) <= skb[k])
                   ##运输类约束
###Constraint （9）:每个节点必须存在于两条弧中
for i in data.N:
    for k in data.K:
        for t in data.T:
            m.addConstr(sum(xijkt[ j,i,k,t] for j in data.N if j!=i)==yikt[i,k,t])
            m.addConstr(sum(xijkt[ i,j,k,t] for j in data.N if i!=j) ==yikt[i,k,t])
###子环消除约束 （10）:  MTZ法
for i in N_Dash:
    for t in data.T:
        for k in data.K:
            for j in data.N:
                if i!=j:
                    m.addConstr((Uikt[i,k,t]-Uikt[j,k,t] + data.Q[k]*xijkt[ i,j,k,t])<= data.Q[k]-sum([qiktp[i,k,t,p] for p in data.P]))

for i in N_Dash:
    for t in data.T:
        for k in data.K:
            m.addConstr(Uikt[i,k,t]<=data.Q[k]) and m.addConstr(Uikt[i,k,t]>=sum([qiktp[i,k,t,p] for p in data.P]))
####Constraint （11）:任一点补货的前提是该点被访问
for i in N_Dash:
    for p in data.P:
        for k in data.K:
            for t in data.T:
                m.addConstr(qiktp[i,k,t,p] <= data.U[i,p] * yikt[i,k,t])

               ##补货类约束
####Constraint （12）: 补送数量小于库存容量
for i in N_Dash:
    for t in data.T:
        for p in data.P:
           if t == 1:
               m.addConstr(sum(qiktp[i,k,t,p]for k in data.K) <= data.U[i,p] - sum(data.Iti_1[i, p] for p in data.P))
           else:
               m.addConstr(sum(qiktp[i,k,t,p]for k in data.K) <= data.U[i,p] - sum(Iitp[i,t-1, p] for p in data.P))
###有效不等式##
for i in data.N:
    for j in data.N:
        for k in data.K:
            for t in data.T:
                if i!=j:
                    m.addConstr(xijkt[ i,j,k,t] <= yikt[i,k,t])
####Constraint 4.14: 补货数量直接达到库存容量
for i in N_Dash:
    for t in data.T:
        for p in data.P:
            if t == 1:
                m.addConstr(sum(qiktp[i,k,t,p] for k in data.K) <= data.U[i,p] - data.Iti_1[i, p] )
            else:
                m.addConstr(sum(qiktp[i,k,t,p] for k in data.K) <= data.U[i,p] - Iitp[i,t-1, p])
##Constraint :车辆使用情况
for k in data.K:
    m.addConstr(1-mk[k]<= 80* yk[k])

for t in data.T:
    for k in data.K:
        m.addConstr(sum(yikt[i,k,t] for i in data.N)-1<=80*(1-yk[k]))

time = round(m.runtime)
#m.write(file_name + 'MTZ.lp')
m.setParam('TimeLimit', 3600)
m.optimize()  #(4421)

# 提取路径数据
xijkt_rout = chang_ijkt_rout(xijkt)

# 绘制路径
if xijkt_rout:
    PlotTour(list(xijkt_rout.values()), data, 'blue')
else:
    print("No routes to plot.")

for v in m.getVars():
    if v.x > 0.01:
        print(v.varName, v.x)
print('Objective:', round(m.objVal, 2))
print('time', m.runtime)
tours=chang_ijkt_rout(xijkt)
print(tours)